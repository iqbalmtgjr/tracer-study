<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Trace Study | Masuk</title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('/asset/img/icon/stkip.png')); ?>" type="image/png">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>dist/css/adminlte.min.css">


</head>

<body class="hold-transition login-page"
    style="background-image: url('<?php echo e(asset('bg.jpg')); ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;">
    <div class="login-box">
        <!-- /.login-logo -->
        <div class="card card-outline card-primary">
            <div class="card-header text-center">
                <img src="<?php echo e(asset('/asset/img/icon/stkip.png')); ?>" alt="Logo STKIP" style="opacity: .8; width: 100px;">
            </div>
            <div class="card-body">
                <p class="login-box-msg">Silahkan Masuk</p>

                <?php echo e($slot); ?>


            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.login-box -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('/')); ?>plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('/')); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('/')); ?>dist/js/adminlte.min.js"></script>
</body>

</html>
<?php /**PATH D:\laragon\www\tracer\resources\views\layouts\guest.blade.php ENDPATH**/ ?>