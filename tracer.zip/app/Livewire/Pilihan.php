<?php

namespace App\Livewire;

use Livewire\Component;

class Pilihan extends Component
{
    public function render()
    {
        return view('livewire.pilihan');
    }
}
